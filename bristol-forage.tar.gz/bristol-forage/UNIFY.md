# Bristol Forage — Full Page Specification Prompt

> Paste this entire prompt into Claude Code. It describes exactly what each page should contain, how it should look, and how all pages connect. Read CLAUDE.md first for colours, fonts, and project context. Then work through each page systematically, building or rebuilding each one to match this spec. Do not skip sections. Do not leave placeholder "TODO" comments. Every feature described below should be implemented and working.

---

## Navigation (src/components/Nav.tsx)

The nav has 5 tabs now (not 3):

**Map** | **Field Guide** | **Essentials** | **Community**

Plus the **Bristol Foraging** brand/logo on the left which links to `/`.

The Community tab shows an orange badge with the pending sightings count (already implemented). On mobile (<768px), switch to a bottom tab bar with icons instead of text labels. Use simple SVG icons: pin for Map, book for Field Guide, shield for Essentials, users for Community.

---

## Page 1: Map (`/` — src/app/page.tsx)

This is the landing page. Full-viewport interactive map. Everything overlays the map — nothing pushes it down.

### Map Base
- Leaflet with OpenStreetMap tiles, centered on Bristol (51.454, -2.594), zoom 12
- Dynamic import with `ssr: false` (already done)
- Zoom controls bottom-right (not default top-left)

### Pins
- Coloured by habitat type: Woodland `#4a7c5f`, Hedgerow `#7a6248`, Wetland `#557278`, Grassland `#6a4878`
- When many pins overlap at lower zoom levels, show a cluster circle with count (e.g. "8 species") that expands on zoom. Use Leaflet.markercluster or a simple custom implementation
- Each pin click opens a popup with: location name, grid ref, habitat badge, short description, species count, and an "Explore" button

### Floating Search Bar (top-left, overlaying map)
- Rounded pill input, white background, shadow
- Searches plant names AND location names
- As user types, show a dropdown of matching results (max 6)
- Selecting a result: if it's a species, zoom to and highlight all locations containing that species. If it's a location, zoom to that pin and open its popup

### Category Filter Chips (below search bar)
- Horizontal row: All | Hedgerow | Fungi | Greens | Herbs | Fruits
- Active chip filled green, others white with border
- Filtering hides pins for locations that don't contain any species in that category

### Seasonal Map Mode (new — below category chips)
- A small toggle or month selector: "Show: In Season Now" vs "All Year"
- When "In Season Now" is active, only show pins for locations that have at least one species currently in season
- The toggle should feel like a natural extension of the filter chips, not a separate UI element

### Season Indicator (bottom-left)
- Small pill: "🌿 March — X species in season"
- Shows current month name and count of in-season species

### "Near Me" Button (bottom-right, above zoom controls)
- Small circular button with a crosshair/GPS icon
- On click: request browser geolocation, pan map to user's position, show a pulsing blue dot
- If permission denied, show a brief toast "Location access needed"

### Location Side Panel (slides from right on desktop, slides up from bottom on mobile)

When "Explore" is clicked on a popup:

**Desktop (>768px):** Panel slides in from the right, 360px wide, full height, white background, shadow

**Mobile (<768px):** Panel slides up from bottom as a draggable sheet, max-height 70vh, with a drag handle bar at the top. Swipe down to close.

Panel contents:
- Location name (serif, green-dark)
- Grid ref · Habitat badge (coloured to match pin)
- **Access** section: how to get there, parking, permissions
- **Description**: what the location is like
- **Species at this location**: chips for each species. Each chip shows the species name. If currently in season, show a green dot on the chip. Clicking a chip navigates to `/guide/[species-slug]`
- **"I saw something here"** button (green outline) — navigates to `/community` with the location pre-filled in the report form
- **"Open Field Guide"** button (green filled) at the bottom

### Map Page — What NOT to include
- No sidebar permanently visible
- No lists or tables — this is a map-first experience
- No scrollable content outside the panel

---

## Page 2: Field Guide (`/guide` — src/app/guide/page.tsx)

The field guide should feel like a **curated botanical reference** that matches the warmth and organic aesthetic of the rest of the site. It is NOT a separate-feeling app — it should use the same typography, colour palette, spacing patterns, and component styles as the map page and species detail pages.

### Layout
**Desktop:** Left sidebar (260px) + main content area (scrollable)
**Mobile:** Sidebar collapses into a sticky top bar with horizontally scrollable category chips and a search input. A toggle button expands/collapses the full species list.

### Left Sidebar
- **Search input** at the top (rounded pill, same style as map search)
- **Category tabs** below: All | Hedgerow | Fungi | Greens | Herbs | Fruits (same categories as map filter, same active styling)
- **Species list**: scrollable list of all species matching the current filter. Each item shows:
  - Checkbox (accent green)
  - Species name (serif)
  - "NOW" pill (green) if in season, otherwise the season range in muted text
- Checking/unchecking a species updates the calendar and cards in real time
- **Select All / Deselect All** toggle at the top of the list

### Main Content Area

**Export Printable Guide** button (brown, top of content) — generates a self-contained HTML file as a Blob download. The exported HTML should include: species name, latin name, season, prep type, habitat, all ID points, harvest notes, uses, storage, full lookalike details, and the legal disclaimer. Style it with inline CSS so it looks good when printed.

**Seasonal Calendar**
- Section heading: "Seasonal Calendar" with the same heading style used across the site (serif, green-dark, border-bottom)
- Table: species as rows, months (J F M A M J J A S O N D) as columns
- Cells: small rounded rectangles. Green if in season. Dark green if current month AND in season. Grey border colour if out of season
- Only shows currently selected (checked) species
- Current month column header is bold green

**Species Cards**
- Section heading: "Species Cards"
- Two-column grid on desktop, single column on mobile
- Each card (white, rounded, subtle shadow, border):
  - Name + "NOW" pill if in season
  - Latin name (italic, muted)
  - Prep badge: "Raw-safe" (green-light bg), "Must cook" (brown-light bg), "Process first" (purple-light bg)
  - Season range + habitat (muted text)
  - Key ID Points (2 bullets with green dots)
  - Lookalike warning box (red-light bg, red text, ⚠ icon) if applicable
  - Relative Nutrition bars (Protein, Vitamin C, Iron) — thin horizontal bars that animate from 0% to their value when the card scrolls into view (IntersectionObserver)
  - Location hint (italic, muted)
  - "Full details →" link to `/guide/[slug]`

### Design Cohesion Rules for This Page
- Use the SAME section heading style everywhere: font-serif, text-forage-green-dark, border-bottom 2px border-forage-border, padding-bottom
- Use the SAME label style for all small uppercase labels: font-sans, text-[9px], uppercase, tracking-widest, text-forage-muted
- Use the SAME card style: white bg, rounded-xl, border border-forage-border, shadow-sm, padding 16px
- Use the SAME chip/badge patterns from the map page for consistency

---

## Page 2b: Species Detail (`/guide/[slug]` — src/app/guide/[slug]/page.tsx)

Individual species pages. These are full dedicated pages, not modals.

### Content (in this order):
1. **Back link**: "← Back to Field Guide"
2. **Species name** (large serif heading) + "IN SEASON" pill if applicable
3. **Latin name** (italic, muted)
4. **Meta badges row**: Prep badge, Season range badge, Category badge, Habitat text
5. **Mini season bar**: 12 small rounded rectangles in a row (one per month), green for in-season months, dark green for current month, grey for out of season. Month initials below.
6. **All Identification Points** — bullet list with green dot markers
7. **Harvest Notes** — paragraph
8. **Uses** — paragraph
9. **Equipment Needed** — paragraph
10. **Storage** — paragraph
11. **Lookalikes (Full)** — in a red-light warning box
12. **Spore Print** — fungi only
13. **Relative Nutrition** — three horizontal bars (same style as cards)
14. **Where to Find It** — location hint (italic) + chips for each location where this species appears, each linking to the map
15. **"I saw this today" button** — green outline button that navigates to `/community` with this species pre-selected in the report form
16. **Previous / Next species** navigation at the bottom
17. **Legal disclaimer** (green-light bg, small text)

---

## Page 3: Foraging Essentials (`/essentials` — NEW PAGE)

This is the education hub. It should feel like a **beautifully designed guidebook** — warm, inviting, not overwhelming.

### Layout
Single column, max-width 800px, centered. Content is presented as **clickable section cards** that expand inline when clicked (accordion style), not separate pages.

### Hero Section
- Heading: "Foraging Essentials" (large serif)
- Subheading: "Everything you need to know before you head out." (muted)
- A row of 3 quick-stat cards: "17 Species in Database", "10 Locations Mapped", "[X] In Season Now" (using real data from species.ts)

### Section Cards (Accordion)
Each section is a card (same card style as the rest of the site: white, rounded, border, shadow). Shows the title and a one-line summary. Clicking expands to show the full content. Only one section open at a time.

**Section 1: Beginner's Guide to Foraging**
- What foraging is and how to start safely
- Start with easy, well-known plants
- Always confirm identification with multiple sources
- Never eat anything you're unsure about
- Learn what's in season before heading out

**Section 2: UK Foraging Laws**
- Personal foraging permitted under the Theft Act 1968
- You may pick for personal use from public land
- Never uproot any plant without landowner permission
- Some species protected under the Wildlife and Countryside Act 1981
- National parks and SSSIs may have additional restrictions (mention Avon Gorge SSSI specifically since it's in the locations database)
- Always stick to public rights of way on private land

**Section 3: Golden Rules of Safe Foraging**
Present as a numbered list with visual emphasis:
1. Never eat a plant unless you are 100% certain of its identity
2. Use multiple identification methods (sight, smell, habitat, season)
3. Watch for toxic lookalikes — especially with fungi, garlic-scented plants, and umbellifers
4. Avoid polluted areas: roadsides, industrial land, sprayed farmland
5. Only take what you need — leave plenty for wildlife
6. Wash all wild food before eating

**Section 4: Plant Identification Basics**
- How to observe: leaf shape, flower structure, smell, stem cross-section, habitat, growing season
- The importance of the "smell test" (wild garlic vs lily of the valley)
- Why habitat matters (chanterelles near oak, wild garlic in damp woodland)
- Link to the Field Guide for detailed ID points

**Section 5: Seasonal Foraging Calendar**
- Brief overview of what appears in each season
- Spring: wild garlic, nettles, three-cornered leek, jack-by-the-hedge
- Summer: elderflower, chanterelles, wood sorrel, yarrow
- Autumn: blackberries, sloes, hawthorn, hazelnuts, hedgehog mushroom, giant puffball
- Winter: rose hips (late), stored preserves
- Link to the Field Guide seasonal calendar for full detail

**Section 6: Dangerous Lookalikes**
- Highlight the key lookalike pairs from the species database:
  - Wild garlic ↔ Lily of the Valley (TOXIC), Lords and Ladies (TOXIC)
  - Elder ↔ Dwarf Elder (TOXIC), Water Hemlock (DEADLY)
  - Yarrow ↔ Poison Hemlock (DEADLY)
  - Chanterelle ↔ False Chanterelle (toxic), Jack-o-lantern (TOXIC)
  - Giant Puffball ↔ Amanita egg (DEADLY)
- For each pair: explain the key distinguishing feature in one sentence
- Red-light warning box styling for the dangerous ones

**Section 7: Sustainable Harvesting**
- Never strip an area bare
- Leave roots intact — never uproot
- Take small amounts from multiple spots
- Protect the habitat for next year
- Some species (like three-cornered leek) are invasive — foraging these actively helps

**Section 8: What to Bring**
- Small sharp knife or scissors
- Basket or paper bags (not plastic — traps moisture)
- Thick gloves (for nettles, sloes, blackthorn)
- Plant identification guide or this website
- Phone for photos and GPS location

**Section 9: Foraging Checklist**
A visual checklist with checkbox styling:
- ☐ Check what's in season (link to Field Guide)
- ☐ Bring a basket, knife, and gloves
- ☐ Know your target species identification
- ☐ Check the weather and ground conditions
- ☐ Only harvest what you can positively identify
- ☐ Leave plenty behind for wildlife
- ☐ Wash everything before eating

**Section 10: 5 Plants Every Beginner Should Learn First**
Feature cards (slightly larger, highlighted) for:
1. Blackberry — safest starting point, no lookalikes in UK
2. Stinging Nettle — unmistakable, incredibly nutritious
3. Wild Garlic — the smell test makes it near-impossible to get wrong
4. Elder — learn flowers AND berries, two harvests per year
5. Hazel — easy nut to identify, satisfying to collect

Each card links to its species detail page.

### Bottom of Page
Link to the Map ("Ready to explore? → Open the Map") and to the Community page ("Found something? → Report a Sighting").

---

## Page 4: Community (`/community` — src/app/community/page.tsx)

The community page has two halves: **the sighting feed** and **the report form**.

### Layout
Single column, max-width 900px, centered.

### Section 1: Recent Activity Feed

**Heading:** "Community Sightings"
**Subheading (muted):** "Recent reports from Bristol foragers"

**Season Tracker** (new — at the very top of the feed):
A highlighted card (green-light background) showing "firsts of the season":
- Scan all approved sightings and find the earliest sighting date for each species in the current year
- Display as: "🌱 First [species] sighting: [date] at [location]"
- If no sightings exist yet, show: "No seasonal firsts recorded yet — be the first to report!"

**Pending Review** section (only visible if pending sightings exist):
- Orange-brown section heading with count
- Grid of sighting cards
- Each card has an "Approve" button and a "Reject" button

**Approved Sightings** section:
- Muted section heading
- Grid of sighting cards (auto-fill, min 280px)
- Each card shows: species name (serif, green-dark), location + date, weather + conditions, notes, submitter name, photo indicator
- Sort by most recent first

### Section 2: Report a Sighting

The form should be **as short as possible**. The goal is minimal friction.

**Heading:** "Report a Sighting"

**Required fields only:**
- **Species**: dropdown from database, PLUS an "Other / Not sure" option. If "Other" is selected, show a free text input
- **Location**: either auto-detect GPS (with a "Use my location" button that shows lat/lng on a mini map preview) OR select from the locations dropdown OR type an OS grid ref. These should be presented as three clear options, not all at once
- **Date**: default to today

**Optional fields (collapsed by default — "Add more details" toggle expands them):**
- Photo upload with thumbnail preview
- Weather
- Ground conditions
- Notes/tips
- Your name (defaults to "Anonymous")

**Submit button** (green, full width on mobile)

**On successful submit:**
- Green toast notification at the top: "Thanks! Your sighting has been submitted for review."
- Form resets
- Sighting appears in the Pending section immediately

**"I saw this today" quick-report flow:**
When arriving at this page with query params `?species=wild-garlic` or `?location=leigh-woods` (from the species detail page or the map side panel), pre-fill those fields automatically. This makes reporting from other pages nearly instant.

### Safety Reminder
Small muted box at the bottom of the form:
"Always verify plant identification before consuming. Personal foraging permitted under the Theft Act 1968."

---

## Cross-Page Design Consistency Rules

These rules must be followed on EVERY page to make the site feel cohesive:

**Typography:**
- Page headings: font-serif (Playfair Display), text-forage-green-dark
- Section headings: font-serif, ~17px, text-forage-green-dark, with a 2px border-bottom in border colour and padding-bottom
- Small labels: font-sans, 9px, uppercase, tracking-widest, text-forage-muted
- Body text: font-sans (Source Sans 3), 13px, text-forage-ink, line-height 1.65

**Colours (never deviate):**
- Primary green: `#4a7c5f` (buttons, active states, in-season indicators, nutrition bars)
- Dark green: `#2d5a3d` (headings, nav background)
- Light green: `#edf4ef` (light backgrounds, highlights)
- Brown: `#7a6248` (secondary accent, export button, hedgerow badge)
- Red: `#8a3a2a` (lookalike warnings only)
- Background: `#f7f5f2` (page bg)
- Borders: `#e8e4de`
- Muted text: `#9a9690`
- Ink/body: `#2a2520`

**Component patterns (reuse everywhere):**
- Cards: white bg, rounded-xl (12px), border border-forage-border, shadow-sm, padding 16px
- Chips/badges: font-sans, text-[11px], px-2.5 py-1, rounded-full, border
- Buttons (primary): bg-forage-green, text-white, rounded-lg, font-serif, hover:bg-forage-green-dark
- Buttons (secondary): border border-forage-green, text-forage-green, rounded-lg, font-serif, hover:bg-forage-green-light
- Warning boxes: bg-forage-red-light, border border-forage-red/20, rounded-md, text-forage-red
- Input fields: border border-forage-border, rounded-lg, font-serif, text-[13px], focus:border-forage-green
- "NOW" pill: bg-forage-green, text-white, rounded-full, font-sans, text-[9px], px-1.5 py-0.5
- Prep badges: raw = green-light bg, cook = brown-light bg, process = purple-50 bg

**Spacing:**
- Consistent section gaps: mb-6 between sections, mb-3 between heading and content
- Page padding: px-5 py-8 for content pages

**Mobile (<768px):**
- All grids go single column
- Side panels become bottom sheets
- Sidebars collapse to top bars
- Minimum tap target 44px
- Full-width buttons

---

## File Structure After This Work

```
src/app/
  page.tsx              → Map (rebuild with clustering, seasonal toggle, near-me, improved search)
  layout.tsx            → Updated nav reference
  guide/
    page.tsx            → Field Guide (rebuild with export, mobile sidebar, animated nutrition bars)
    [slug]/page.tsx     → Species detail (add prev/next, "I saw this today", improved layout)
  essentials/
    page.tsx            → NEW — Foraging Essentials education hub
  community/
    page.tsx            → Community (rebuild with season tracker, quick-report flow, collapsible optional fields, toast notifications)
src/components/
  Nav.tsx               → Updated: 4 tabs, mobile bottom bar
  map/
    MapView.tsx         → Rebuilt with all map features
    LocationPanel.tsx   → Rebuilt with mobile bottom sheet
  (other components as needed — extract reusable pieces like SectionHeading, Card, Badge, Toast, etc.)
```

Work through each page in order: Nav → Map → Field Guide → Species Detail → Essentials → Community. Build and test each before moving to the next. Extract shared components as you go so the design stays consistent.
